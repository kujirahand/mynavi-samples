<?php
// config.php
// データベース設定
define('DB_PATH', __DIR__ . '/data/notes.db');

// 認証情報
define('USER_NAME', 'my-notepad');
define('PASSWORD', 'Tg0s4lmO9m1o1N8M');

// セッション設定
define('SESSION_NAME', 'MyNotepad');
