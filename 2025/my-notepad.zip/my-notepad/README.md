# AIがPHPで開発したWebアプリ「メモ帳」

以下のユーザー名とパスワードで利用できます。

  - ユーザー名: my-notepad
  - パスワード: Tg0s4lmO9m1o1N8M)
- **フロントエンド**: HTML/CSS

実際に利用する際は、config.phpで変更してください。
